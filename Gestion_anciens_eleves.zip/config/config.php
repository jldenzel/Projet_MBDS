
<?php 
// Modifier le 21-03-2020
//session_start();
/* DATABASE CONFIGURATION */
define("DB_SERVER", "localhost:1521/orcl");
define("DB_USERNAME", "c##je");
define("DB_PASSWORD", "******");
define("DB_DATABASE", "gestion_anciens_eleves");

date_default_timezone_set('Europe/Paris');


function getDB(){
	$dbhost=DB_SERVER;
	$dbuser=DB_USERNAME;
	$dbpass=DB_PASSWORD;
	$dbname=DB_DATABASE;
	try {
		$conn = oci_connect($dbuser,$dbpass,$dbhost);
		//$conn = oci_connect($dbuser, $dbpass, '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = LOCALHOST)(PORT = 1521)) (CONNECT_DATA = (SERVICE_NAME = ORCL) (SID = ORCL)))');
		if (!$conn) {
			$e = oci_error();
			trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
		}
		return $conn;
		}
	catch (PDOException $e) {
	echo "connection failed:" .$e->getMessage();
		}
}

?>