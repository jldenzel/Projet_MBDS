Dans /config/config.php se situe le fichier contenant la chaîne de connexion à la bdd.
Modifier avec les données de votre bdd les variables de connexion. 


mettre le dossier "ancien_eleve" ici (si vous travaillez sous wampp64) C:\wamp64\www
veillez à lancer wampp server avant de se connecter sur le site (touche window, taper wampsever64 et exécuter, il va tourner en arrière plan).

allez à cette adresse : http://localhost/ancien_eleve  le fichier "index.php" vous redirigera automatiquement vers la page de connexion.


pour créer un nouvel utilisateur dans la bdd, ouvrez le fichier "user.php" (dans le dossier front), modifier le login et le mdp avant 
de l'executer à cette adresse : http://localhost/front/user.php