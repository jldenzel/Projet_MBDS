<?php
header("Location: front/ajouter_eleve.php");
?>