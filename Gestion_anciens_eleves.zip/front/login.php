<!DOCTYPE html>
<html lang="fr" >
<head>
  <meta charset="UTF-8">
  <title>Connexion</title>
<link rel="stylesheet" href="..\css\connexion.css"/>

</head>
<body>
<?php
include ('..\config\config.php');
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
$db=getDB();
session_start();
if(isset($_POST['username'])){
	$username=$_REQUEST['username'];
	$password=$_REQUEST['password'];
	$password = hash('sha256',$password);
	$q=oci_parse($db,'SELECT * FROM userapp WHERE username=:username AND password=:password');
	oci_bind_by_name($q,':username',$username);
	oci_bind_by_name($q,':password',$password);
	oci_execute($q);
	if ($row = oci_fetch_array($q, OCI_ASSOC+OCI_RETURN_NULLS)) 
	{
		$_SESSION['username'] = $username;
		$_SESSION['id_user'] = $row['username'];
		header("Location: ..\index.php");
		
	}else
	{
		$message = "Le nom d'utilisateur ou le mot de passe est incorrect.";
	}
	
}



?>


<div class="login-form">
  <h1>Connexion</h1>
  <form method="post" action="">
    <label for="username">Pseudonyme</label>
    <input id="username" type="text" name="username" placeholder="Pseudonyme"/>
    <label for="password">Mot de passe</label>
    <input id="password" type="password" name="password" placeholder="Mot de passe"/>
    <input type="submit" name="login-form-submit" value="Connexion"/>
	
	<?php if (! empty($message)) { ?>
    <p class="errorMessage"><?php echo $message; ?></p>
<?php } ?>
  </form>
</div>
</body>
</html>

