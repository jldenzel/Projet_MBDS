<?php
include('header.html');
include ('..\config\config.php');
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
$db=getDb();
$etudiantManager = new EtudiantManager($db);
$etudiant = $etudiantManager->getList();
echo"<form name='form' method='post' action='".$_SERVER["PHP_SELF"]."'>";

echo'<input type="text" list="Etudiant" id="etudiant" name="etudiant"/>';
echo'<datalist id="Etudiant">';
//while ($row = oci_fetch_array($req, OCI_ASSOC+OCI_RETURN_NULLS)) 
foreach($etudiant as $row)
{
	//echo'<option value = '.$row['NUMERO_ETUDIANT'].'>'.$row['NOM_ETUDIANT'].'</option>';
	echo'<option value = '.$row->numero_etudiant().'>'.$row->nom_etudiant().'</option>';
}
		
echo'</datalist>';
echo "<input type='submit' value='valider' class='submit' name='modif'/></br>";
echo'</form>';

if(isset($_POST['modif']))
{
	$etudiantManager = new EtudiantManager($db);
	$entreprise = new EntrepriseManager($db);
	$etudiant = $etudiantManager->getList('id',$_POST['etudiant']);
	$row = $etudiant[0];
	

echo"<table class='tab_affich'>";
	echo"<thead>";
		echo"<tr>";
			echo"<th>Prenom</th>";
			echo"<th>Nom</th>";
			echo"<th>Nationalite</th>";
			echo"<th>Promotion</th>";
			echo"<th>Entreprise</th>";
			echo"<th>Lien Contact</th>";
		echo"</tr>";
	echo"</thead>";
	echo"<tbody>";

	echo"<tr>";
	echo"<td>".$row->prenom()."</td>";
	echo"<td>".$row->nom_etudiant()."</td>";
	echo"<td>".$row->nationalite()."</td>";
	echo"<td>".$row->promotion()."</td>";
	echo"<td></td>";
	echo"<td></td>";
	echo"</tr>";
echo"</tbody>";

echo"<form name='form' method='post' action='".$_SERVER["PHP_SELF"]."'>";

echo"<table class='tab_affich'>";
echo"<tr><td>Diplome(s) réalisé(s)</td>";
//on recupère les diplomes réalisés par l'étudiant
$realiseManager = new RealiseManager($db);
$realise = $realiseManager->getList($crit='etudiant',$value=$_POST['etudiant']);
//on récupère tous les diplomes que notre école fait
$diplomeManager = new DiplomeManager($db);
$diplome = $diplomeManager->getList();
//si l'étudiant à réalisé au moins un diplome

	
foreach($diplome as $row_dip)
{
	$tab_dip[$row_dip->nom_diplome()][$row_dip->numero_diplome()]='';
}
if(!empty($realise))
{
	foreach($realise as $dip)
	{
		$diplome_rea = $diplomeManager->getList($crit = 'numero_diplome',$value = $dip->numero_diplome() );
		$tab_dip[$diplome_rea[0]->nom_diplome()][$dip->numero_diplome()]='checked';
	}
}
foreach($tab_dip as $key=>$value)
{
	echo"<td><input type='checkbox' id = '".key($value)."' name = 'diplome[]' value='".key($value)."' ".$value[key($value)].">    ".$key."</td>";
	
}

echo"</tr>";
echo"</table>";
//table des matière/crédits par diplome
echo"<table>";
foreach($realise as $diplome)
{
	
	echo"<tr>";
	//affichage des matières correspondants au diplome 
	$num_dip = $diplome->numero_diplome();
	
	$q="SELECT * FROM matiere 
	INNER JOIN comporte ON comporte.numero_matiere = matiere.numero_matiere
	INNER JOIN diplome ON diplome.numero_diplome = comporte.numero_diplome
	WHERE diplome.numero_diplome =$num_dip ";
	//print_r($q);
	$req1=oci_parse($db,$q);
	//oci_bind_by_name($req1,':num_diplome',$num_dip);
	oci_execute($req1);
	echo"aaaaaaaaaa";
	while ($r =oci_fetch_row($req1))
	{
		echo"bbbbbbbbbbbb";
		print_r($r);
		
		echo"<td>";
		//liste déroulante des grades 
		$req=oci_parse($db,"SELECT * FROM grade ORDER BY grade");
		oci_execute($req);
		echo"<select name='grade'>";
		while ($row = oci_fetch_array($req, OCI_ASSOC+OCI_RETURN_NULLS))
		{
			echo "<option value=".$row['NUMERO_GRADE'].">".$row['GRADE']."</option>\n";
		}
		echo"</select>";
		echo"</td>";
	}
	echo"ccccc";
	echo"</tr>";
}
echo"</table>";

echo'<input id="numero_etudiant" name="numero_etudiant" type="hidden" value="'.$row->numero_etudiant().'">';
echo "<input type='submit' value='valider les changements' class='submit' name='modif_eleve'/></br>";
}

//cas ou on demande une modification de la fiche élève
elseif(isset($_POST['modif_eleve']))
{
	
	$realiseManager = new RealiseManager($db);
	//si on a renseigné un ou des diplome
	if(isset($_POST['diplome']))
	{
		//on supprime les appartenance (diplome réalisé) présentes dans la bdd
		$tmp = $realiseManager->getList($crit='etudiant',$value=$_POST['numero_etudiant']);
		foreach($tmp as $row)
		{
			$realiseManager->delete_realise($row->numero_etudiant(),$row->numero_diplome());
		}
		//on boucle sur le post pour récuperer les nouvelles appartenances 
		foreach($_POST['diplome'] as $diplome)
		{

			//on insère le diplome
			$realise = new Realise(['numero_diplome'=>$diplome,
			'numero_etudiant'=>$_POST['numero_etudiant']]);
			$realiseManager->add($realise);

		}
	}
	else
	{
		//on supprime les appartenance (diplome réalisé)
		$tmp = $realiseManager->getList($crit='etudiant',$value=$_POST['numero_etudiant']);
		foreach($tmp as $row)
		{
			$realiseManager->delete_realise($row->numero_etudiant(),$row->numero_diplome());
		}
	}
	
	
}

include('footer.html');
?>


