<?php
include('header.html');
include ('..\config\config.php');
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
$db=getDb();

$etudiantManager = new EtudiantManager($db);
$entreprise = new EntrepriseManager($db);
$etudiant = $etudiantManager->getList();

echo"<table class='tab_affich'>";
	echo"<thead>";
		echo"<tr>";
			echo"<th>Prenom</th>";
			echo"<th>Nom</th>";
			echo"<th>Nationalite</th>";
			echo"<th>Promotion</th>";
			echo"<th>Entreprise</th>";
			echo"<th>Lien Contact</th>";
			echo"<th></th>";
		echo"</tr>";
	echo"</thead>";
	echo"<tbody>";
	foreach($etudiant as $row)
	{
		echo"<tr>";
		echo"<td>".$row->prenom()."</td>";
		echo"<td>".$row->nom_etudiant()."</td>";
		echo"<td>".$row->nationalite()."</td>";
		echo"<td>".$row->promotion()."</td>";
		echo"<td></td>";
		echo"<td></td>";
		echo"<td><input type='checkbox' id='".$row->numero_etudiant()."' value='".$row->numero_etudiant()."' name='selection[]'></td> ";
		echo"</tr>";
	}
echo"</tbody>";


include('footer.html');
?>