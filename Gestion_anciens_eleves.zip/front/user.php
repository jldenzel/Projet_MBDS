<?php
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
//variables a modifier
$username = "admin1";
$password = "admin1";




$password = hash('sha256',$password);
$q = "INSERT INTO userapp (username, password) values (:username,:password)";
$req = oci_parse($db,$q);
oci_bind_by_name($req,':password',$password);
oci_bind_by_name($req,':username',$username);

?>