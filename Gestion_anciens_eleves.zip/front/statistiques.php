<?php
include('header.html');
include ('..\config\config.php');
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
$db=getDb();


//nb d'etudiant dans chaque entreprise 
//nb d'eleve par diplome 

include('footer.html');
?>

