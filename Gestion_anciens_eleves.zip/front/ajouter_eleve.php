<?php
include('header.html');
include ('..\config\config.php');
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
$db=getDb();
echo"<form name='form' method='post' action='".$_SERVER["PHP_SELF"]."'>";
echo"<table class='tab_affich'>";
	echo"<thead>";
		echo"<tr>";
			echo"<th>Nom de l'etudiant</th>";
			echo"<th>Prenom de l'étudiant</th>";
			echo"<th>Nationalite</th>";
			echo"<th>Promotion</th>";
			echo"<th>Mention</th>";
			echo"<th>Entreprise</th>";							
		echo"</tr>";
	echo"</thead>";
	echo"<tbody>";

	
	
	echo'<td><input type="text" name="name"></td>';
	echo'<td><input type="text" name="firstname"></td>';
	echo'<td><input type="text" name="nationalite"></td>';
	echo'<td><input type="text" name="promo"></td>';
	echo'<td><input type="text" name="mention"></td>';
	
	$entreprise = new EntrepriseManager($db);
	$tab_enteprise = $entreprise->getList();
	echo"<td><select name='entreprise'>";
	foreach($tab_enteprise as $row){
		echo "<option value=".$row->numero_entreprise().">".$row->nom_entreprise()."</option>\n";
	}
	echo"</select></td>";
	
	/*$diplome = new DiplomeManager($db);
	$tab_diplome = $diplome->getList();
	echo"<td><select name='diplome'>";
	foreach($tab_diplome as $row){
		echo "<option value=".$row->nom_diplome().">".$row->nom_diplome()."</option>\n";
	}
	echo"</select></td>";*/

	
	
	
	
echo"</tbody>";
echo"</table><br>";
echo "<input type='submit' value='valider' class='submit' name='modif'/></br>";
echo'</form>';

if(isset($_POST['modif']))
{

	$etudiantManager = new EtudiantManager($db);
	$date_naissance = DateTime::createFromFormat('j-M-y', $_POST['date_naissance']);
	$etudiant = new Etudiant([
	'prenom'=>$_POST['firstname'],
	'nationalite'=>$_POST['nationalite'],
	'promotion'=>$_POST['promo'],
	'mention'=>$_POST['mention'],
	'nom_etudiant'=>$_POST['name'],
	'numero_entreprise'=>$_POST['entreprise']
	]);
	
	$etudiantManager->add($etudiant);
}


include('footer.html');
?>