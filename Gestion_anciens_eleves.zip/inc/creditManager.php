<?php
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
/*
**Class RealiseManager
**ne prendqs en constructeur que la base de donnees ($db)
**Cette classe sert à intéragir avec la base de données (table Etudiant uniquement)
**Elle comporte les méthodes d'ajout,delete, update et get
*/

class RealiseManager {
	
	//seul attribut de la classe : la bdd
	private $_db;
	
	//constructeur
	public function __construct($db)
	{
		$this->_db=$db;
	}
	
	/*
	**méthode de la class EtudiantManager permettant d'ajouter un étudiant à la bdd
	**la méthode prends en paramètre un objet de type Etudiant
	*/
	public function add($credit)
	{
		
		//requête d'insertion de données
		//les ":" devant les variables servent à renseigner ces champs ulterieurement dans le code
		
		$q="INSERT INTO a_obtenu (numero_etudiant,numero_grade,numero_matiere,numero_diplome) 
		VALUES(:numero_etudiant,:numero_grade,:numero_matiere,:numero_diplome)";
		$q = oci_parse($this->_db,$q);
		//on remplace les valeurs par les attribut d'étudiants
		
		oci_bind_by_name($q,':numero_etudiant',$numero_etudiant);
		oci_bind_by_name($q,':numero_grade',$numero_etudiant);
		oci_bind_by_name($q,':numero_matiere',$numero_etudiant);
		oci_bind_by_name($q,':numero_diplome',$numero_diplome);
		
		oci_execute($q);
	}
	
	/*
	**Methode permetant de sortir la liste d'étudiant dans la bdd. 
	**Elle a 2 paramètre facultatif : 
	**** $crit qui est le champ sur lequel on veut tester
	**** $value la valeur qu'on lui attribut 
	** exemple : $crit = 'promio', $value ='2021'
	**ces paramètre sont par défaut à NULL, ce qui veut dire qu'il n'y a pas de clause WHERE dans la requete sql
	*/
	public function getList()
	{
		
		$q="SELECT * FROM grade 
		JOIN a_obtenu ON a_obtenu.numero_grade = grade.numero_grade
		JOIN matiere ON matiere.numero_matiere = a_obtenu.numero_matiere
		JOIN etudiant ON etudiant.numero_etudiant = a_obtenu.numero_etudiant
		JOIN diplome ON diplome.numero_diplome = a_obtenu.numero_diplome
		WHERE etudiant.numero = 
		AND diplome.numero = 
		AND matiere.numero =
		";		
		$q=oci_parse($this->$db,$q);
		
		
		oci_execute($q);
		
		
		
		oci_execute($q);
		while ($row = oci_fetch_array($q, OCI_ASSOC+OCI_RETURN_NULLS)) 
		{
			
			//on déclare un objet de type etudiant pour chaque ligne retourné par la requête
			$realise[] = new Realise($row);
		}
		//on retourne le tableau d'étudaint
		return $realise;
	}
	
	/*Methode servant à supprimer un etudiant dans la bdd
	**Elle prend en paramètre l'id de l'etudiant que l'on souhaite supprimer
	*/
	public function delete_realise($numero_etudiant, $numero_diplome)
	{
		$q = oci_parse($this->_db,"DELETE FROM realise WHERE numero_etudiant = :numero_etudiant AND numero_diplome = :numero_diplome");
		oci_bind_by_name($q,':numero_etudiant',$numero_etudiant);
		oci_bind_by_name($q,':numero_diplome',$numero_diplome);
		oci_execute($q);
	}
	
}


?>