<?php
/*
**Classe etudiant représentant la table étudiant de la bdd
**
*/
class Diplome 
{
	private $_nom_diplome;
	private $_numero_diplome;

	
	public function __construct ($value = array())
	{
		if(!empty($value))
			$this->hydrate($value);
	}
	
	public function hydrate(array $data)
	{
		foreach($data as $key => $value)
		{
			$method = 'set'.ucfirst($key);
			if(method_exists($this, $method))
			{
				$this->$method($value);
			}
		}
	}
	
	public function nom_diplome(){return $this->_nom_diplome;}
	public function numero_diplome(){return $this->_numero_diplome;}

	
	
	public function setNom_diplome($nom_diplome)
	{
		$this->_nom_diplome=$nom_diplome;
	}
	public function setNumero_diplome($numero_diplome)
	{
		$this->_numero_diplome=$numero_diplome;
	}


}
?>