<?php
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
/*
**Class DiplomeManager
**ne prendqs en constructeur que la base de donnees ($db)
**Cette classe sert à intéragir avec la base de données (table Association uniquement)
**Elle comporte les méthodes d'ajout,delete et get
*/

class DiplomeManager {
	
	//seul attribut de la classe : la bdd
	private $_db;
	
	//constructeur
	public function __construct($db)
	{
		$this->_db=$db;
	}
	
	/*
	**méthode de la class contactManager permettant d'ajouter un diplome à la bdd
	**la méthode prends en paramètre un objet de type association
	*/
	public function add($diplome)
	{
		//requête d'insertion de données
		//les ":" devant les variables servent à renseigner ces champs ulterieurement dans le code
		$q = oci_parse($this->_db,"INSERT INTO diplome(nom_diplome,numero_diplome)
		VALUES(:nom_diplome,:numero_diplome)");
		//on remplace les valeurs par les attribut de diplomes
		oci_bind_by_name($q,':nom_diplome',$diplome->nom_diplome());
		oci_bind_by_name($q,':numero_diplome',$diplome->numero_diplome());

		//execution de la requete
		oci_execute($q);
	}
	
	/*
	**Methode permetant de sortir la liste de diplomes dans la bdd. 
	**Elle a 2 paramètre facultatif : 
	**** $crit qui est le champ sur lequel on veut tester
	**** $value la valeur qu'on lui attribut 
	**ces paramètre sont par défaut à NULL, ce qui veut dire qu'il n'y a pas de clause WHERE dans la requete sql
	*/
	public function getList($crit=NULL,$value=NULL)
	{
		//déclaration du tableau stockant le retour de la requête : les diplomes
		$diplome=[];
		//si des critère de recherches sont passé en paramètre 
		if(!empty($crit) && !empty($value))
		{
			//on exécute une requête avec une clause WHERE qui prends en compte les paramètre donnés.
			$q=oci_parse($this->_db,'SELECT * FROM diplome WHERE numero_diplome='.$value.'');
		}
		//sinon la requête ne comporte pas de paramètres
		else
		{
			$q=oci_parse($this->_db,'SELECT * FROM diplome ORDER BY nom_diplome');
		}
		//on boucle sur les résultat de la requete afin de pouvoir les renvoyer proprement
		oci_execute($q);
		while ($row = oci_fetch_array($q, OCI_ASSOC+OCI_RETURN_NULLS)) 
		{
			
			//on déclare un objet de type association pour chaque ligne retourné par la requête
			$diplome[] = new diplome($row);
		}
		//on retourne le tableau d'association
		return $diplome;
	}
	
	/*Methode servant à supprimer un diplome dans la bdd
	**Elle prend en paramètre l'id du diplome que l'on souhaite supprimer
	*/
	public function delete_diplome($id)
	{
		$q = oci_parse($this->_db,"DELETE FROM diplome WHERE id=:id");
		oci_bind_by_name($q,':id',$id);
		oci_execute($q);
	}
	
	
	/*requete servant à mettre un jour une ligne dans la bdd
	**elle prend en paramètre l'objet de type diplome que l'on souhaite modifier
	*/
	public function update($diplome)
	{
		$q = oci_parse($this->_db,"UPDATE dplome SET adresse_postale=:adresse_postale,adresse_email=:adresse_email,
		ville=:ville,numero_telephone=:numero_telephone,numero_contact=:numero_contact");
		
		oci_bind_by_name($q,':nom_diplome',$diplome->nom_diplome());
		oci_bind_by_name($q,':numero_diplome',$diplome->numero_diplome());
		
		oci_execute($q);
	}
	
}


?>
