<?php
class Matiere
{
	private $_credit;
	private $_nom_matiere;
	private $_numero_matiere;
	private $_numero_grade;
	
	
	public function __construct ($value = array())
	{
		if(!empty($value))
			$this->hydrate($value);
	}
	
	public function hydrate(array $data)
	{
		foreach($data as $key => $value)
		{
			$method = 'set'.ucfirst($key);
			if(method_exists($this, $method))
			{
				$this->$method($value);
			}
		}
	}
	
	public function credit(){return $this->_credit;}
	public function nom_matiere(){return $this->_nom_matiere;}
	public function numero_matiere(){return $this->_numero_matiere;}
	public function numero_grade(){return $this->_numero_grade;}
	
	
	public function setCredit($credit)
	{
		$this->_credit=$credit;
	}
	public function setNom_matiere($nom_matiere)
	{
		$this->_nom_matiere=$nom_matiere;
	}
	public function setNumero_matiere($numero_matiere)
	{
		$this->_numero_matiere=$numero_matiere;
	}
	public function setNumero_grade($numero_grade)
	{
		$this->_numero_grade=$numero_grade;
	}
	
	
}

?>