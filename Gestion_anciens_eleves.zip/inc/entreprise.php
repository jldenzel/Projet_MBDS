<?php
class Entreprise
{
	private $_pays;
	private $_activite_entreprise;
	private $_nom_entreprise;
	private $_Numero_entreprise;
	
	public function __construct ($value = array())
	{
		if(!empty($value))
			$this->hydrate($value);
	}
	
	public function hydrate(array $data)
	{
		foreach($data as $key => $value)
		{
			$method = 'set'.ucfirst($key);
			if(method_exists($this, $method))
			{
				$this->$method($value);
			}
		}
	}
	
	
	public function pays(){return $this->_pays;}
	public function activite_entreprise(){return $this->_activite_entreprise;}
	public function nom_entreprise(){return $this->_nom_entreprise;}
	public function numero_entreprise(){return $this->_Numero_entreprise;}
	
	public function setPays($pays)
	{
		$this->_pays=$pays;
	}
	public function setActivite_entreprise($activite_entreprise)
	{
		$this->_activite_entreprise=$activite_entreprise;
	}
	public function setNom_entreprise($nom_entreprise)
	{
		$this->_nom_entreprise=$nom_entreprise;
	}
	public function setNumero_entreprise($numero_entreprise)
	{
		$this->_Numero_entreprise=$numero_entreprise;
	}
	
}

?>