<?php
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
/*
**Class EntrepriseManager
**ne prendqs en constructeur que la base de donnees ($db)
**Cette classe sert à intéragir avec la base de données (table entreprise uniquement)
**Elle comporte les méthodes d'ajout, update et get
*/

class EntrepriseManager {
	
	//seul attribut de la classe : la bdd
	private $_db;
	
	//constructeur
	public function __construct($db)
	{
		$this->_db=$db;
	}
	
	/*
	**méthode de la class EntrepriseManager permettant d'ajouter un étudiant à la bdd
	**la méthode prends en paramètre un objet de type Entreprise
	*/
	public function add($entreprise)
	{
		//requête d'insertion de données
		//les ":" devant les variables servent à renseigner ces champs ulterieurement dans le code
		$q = oci_parse($this->_db,"INSERT INTO entreprise(pays,activite_entreprise,nom_entreprise,numero_entreprise)
		VALUES(:pays,:activite_entreprise,:nom_entreprise,:numero_entreprise");
		//on remplace les valeurs par les attribut d'entreprises
		oci_bind_by_name($q,':pays',$entreprise->pays());
		oci_bind_by_name($q,':activite_entreprise',$entreprise->activite_entreprise());
		oci_bind_by_name($q,':nom_entreprise',$entreprise->nom_entreprise());
		oci_bind_by_name($q,':numero_entreprise',$entreprise->numero_entreprise());

		//execution de la requete
		oci_execute($q);
	}
	
	/*
	**Methode permetant de sortir la liste d'entreprises dans la bdd. 
	**Elle a 2 paramètre facultatif : 
	**** $crit qui est le champ sur lequel on veut tester
	**** $value la valeur qu'on lui attribut 
	**ces paramètre sont par défaut à NULL, ce qui veut dire qu'il n'y a pas de clause WHERE dans la requete sql
	*/
	public function getList($crit=NULL,$value=NULL)
	{
		//déclaration du tableau stockant le retour de la requête : les étudiants
		$entreprise=[];
		//si des critère de recherches sont passé en paramètre 
		if(!empty($crit) && !empty($value))
		{
			//on exécute une requête avec une clause WHERE qui prends en compte les paramètre donnés.
			$q=oci_parse($this->_db,"SELECT * FROM entreprise WHERE numero_entreprise = :value ");
			//oci_bind_by_name($q,':crit',$crit);
			oci_bind_by_name($q,':value',$value);
			oci_execute($q);
			//print_r('SELECT * FROM entreprise WHERE '.$crit.'='.$value.' ORDER BY '.$crit.' ');
			$entreprise[] = oci_fetch_assoc($q);
		}
		//sinon la requête ne comporte pas de paramètres
		else
		{
			$q=oci_parse($this->_db,'SELECT * FROM entreprise ORDER BY nom_entreprise');
			oci_execute($q);
			while ($row = oci_fetch_array($q, OCI_ASSOC+OCI_RETURN_NULLS)) 
		{
			//on déclare un objet de type etudiant pour chaque ligne retourné par la requête
			$entreprise[] = new Entreprise($row);
		}
			
		}
		//on boucle sur les résultat de la requete afin de pouvoir les renvoyer proprement
		
		
		
		//on retourne le tableau d'entreprises
		return $entreprise;
	}
	
	/*Methode servant à supprimer une entreprise dans la bdd
	**Elle prend en paramètre l'id de l'etudiant que l'on souhaite supprimer
	*/
	public function delete_entreprise($id)
	{
		$q = oci_parse($this->_db,"DELETE FROM entreprise WHERE id=:id");
		oci_bind_by_name($q,':id',$id);
		oci_execute($q);
	}
	
	
	/*requete servant à mettre un jour une ligne dans la bdd
	**elle prend en paramètre l'objet de type entrepriseque l'on souhaite modifier
	*/
	public function update($entreprise)
	{
		$q = oci_parse($this->_db,"UPDATE entreprise SET pays=:pays,activite_entreprise=:activite_entreprise,
		nom_entreprise=:nom_entreprise,numero_entreprise=:numero_entreprise");
		
oci_bind_by_name($q,':pays',$entreprise->pays());
		oci_bind_by_name($q,':pays',$entreprise->pays());
		oci_bind_by_name($q,':activite_entreprise',$entreprise->activite_entreprise());
		oci_bind_by_name($q,':nom_entreprise',$entreprise->nom_entreprise());
		oci_bind_by_name($q,':numero_entreprise',$entreprise->numero_entreprise());
		
		oci_execute($q);
	}
	
}


?>