<?php
spl_autoload_register(function ($class_name){
	include "..\inc\\".$class_name.'.php';
	
});
/*
**Class RealiseManager
**ne prendqs en constructeur que la base de donnees ($db)
**Cette classe sert à intéragir avec la base de données (table Etudiant uniquement)
**Elle comporte les méthodes d'ajout,delete, update et get
*/

class RealiseManager {
	
	//seul attribut de la classe : la bdd
	private $_db;
	
	//constructeur
	public function __construct($db)
	{
		$this->_db=$db;
	}
	
	/*
	**méthode de la class EtudiantManager permettant d'ajouter un étudiant à la bdd
	**la méthode prends en paramètre un objet de type Etudiant
	*/
	public function add($realise)
	{
		
		//requête d'insertion de données
		//les ":" devant les variables servent à renseigner ces champs ulterieurement dans le code
		$q = oci_parse($this->_db,"INSERT INTO realise(numero_etudiant,numero_diplome)
		VALUES(:numero_etudiant,:numero_diplome)");
		//on remplace les valeurs par les attribut d'étudiants
		$numero_etudiant = $realise->numero_etudiant();
		oci_bind_by_name($q,':numero_etudiant',$numero_etudiant);
		$numero_diplome = $realise->numero_diplome();
		oci_bind_by_name($q,':numero_diplome',$numero_diplome);
		
		oci_execute($q);
	}
	
	/*
	**Methode permetant de sortir la liste d'étudiant dans la bdd. 
	**Elle a 2 paramètre facultatif : 
	**** $crit qui est le champ sur lequel on veut tester
	**** $value la valeur qu'on lui attribut 
	** exemple : $crit = 'promio', $value ='2021'
	**ces paramètre sont par défaut à NULL, ce qui veut dire qu'il n'y a pas de clause WHERE dans la requete sql
	*/
	public function getList($crit=NULL,$value=NULL, $crit2=NULL, $value2=NULL)
	{
		//déclaration du tableau stockant le retour de la requête : les étudiants
		$realise=[];
		//si des critère de recherches sont passé en paramètre 
		if($crit=='diplome'&& !empty($value))
		{
			//on exécute une requête avec une clause WHERE qui prends en compte les paramètre donnés.
			$q=oci_parse($this->_db,'SELECT * FROM realise WHERE numero_diplome=:id');
			oci_bind_by_name($q,':id',$value);
		}
		elseif($crit = 'etudiant' && !empty($value) && $crit2='diplome' && !empty($value2))
		{
			//on exécute une requête avec une clause WHERE qui prends en compte les paramètre donnés.
			$q=oci_parse($this->_db,'SELECT * FROM realise WHERE numero_etudiant=:id AND numero_diplome=:diplome');
			oci_bind_by_name($q,':id',$value);
			oci_bind_by_name($q,':diplome',$value2);
		}
		elseif($crit = 'etudiant' && !empty($value))
		{
			//on exécute une requête avec une clause WHERE qui prends en compte les paramètre donnés.
			$q=oci_parse($this->_db,'SELECT * FROM realise WHERE numero_etudiant=:id');
			oci_bind_by_name($q,':id',$value);
		}
		
		//sinon la requête ne comporte pas de paramètres
		else
		{
			$q=oci_parse($this->_db,'SELECT * FROM realise ');
		}
		//on boucle sur les résultat de la requete afin de pouvoir les renvoyer proprement
		oci_execute($q);
		while ($row = oci_fetch_array($q, OCI_ASSOC+OCI_RETURN_NULLS)) 
		{
			
			//on déclare un objet de type etudiant pour chaque ligne retourné par la requête
			$realise[] = new Realise($row);
		}
		//on retourne le tableau d'étudaint
		return $realise;
	}
	
	/*Methode servant à supprimer un etudiant dans la bdd
	**Elle prend en paramètre l'id de l'etudiant que l'on souhaite supprimer
	*/
	public function delete_realise($numero_etudiant, $numero_diplome)
	{
		$q = oci_parse($this->_db,"DELETE FROM realise WHERE numero_etudiant = :numero_etudiant AND numero_diplome = :numero_diplome");
		oci_bind_by_name($q,':numero_etudiant',$numero_etudiant);
		oci_bind_by_name($q,':numero_diplome',$numero_diplome);
		oci_execute($q);
	}
	
	
	/*requete servant à mettre un jour une ligne dans la bdd
	**elle prend en paramètre l'objet de type etudiant que l'on souhaite modifier
	*/
	/*public function update($etudiant)
	{
		$q = oci_parse($this->_db,"UPDATE etudiant SET prenom=:prenom,nationalite=:nationalite,
		date_naissance=:date_naissance,promotion=:promotion,mention=:mention,nom_etudiant=:nom_etudiant");
		
		oci_bind_by_name($q,':prenom',$etudiant->prenom());
		oci_bind_by_name($q,':nationalite',$etudiant->nationalite());
		oci_bind_by_name($q,':date_naissance',$etudiant->date_naissance());
		oci_bind_by_name($q,':promotion',$etudiant->promotion());
		oci_bind_by_name($q,':mention',$etudiant->mention());
		oci_bind_by_name($q,':nom_etudiant',$etudiant->nom_etudiant());
		oci_bind_by_name($q,':numero_entreprise',$etudiant->numero_entreprise());
		oci_bind_by_name($q,':numero_contact',$etudiant->numero_contact);
		
		oci_execute($q);
	}*/
	
	
	/* Methode sortant toute les information sur un etudiant (contact, dipmlomes...) 
	**
	*/
	/*public function get_etudiant_all($id)
	{
		
		
		$q=oci_parse($this->_db,'SELECT * FROM etudiant WHERE id=:id
		JOIN contact ON  contact.numero_contact= etudiant.numero_contact 
		JOIN entreprise ON entreprise.numero_entreprise = etudiant.numero_entreprise	
		JOIN a_obtenu ON a_obtenu.numero_etudiant = etudiant.numero_etudiant
		JOIN grade ON grade.numero_grade = a_obtenu.numero_grade
		JOIN matiere ON matiere.numero = a_obtenu.numero_matiere
		JOIN diplome on numero_diplome = ');
		oci_bind_by_name($q,':id',$id);
		//on boucle sur les résultat de la requete afin de pouvoir les renvoyer proprement
		oci_execute($q);
		while ($row = oci_fetch_array($q, OCI_ASSOC+OCI_RETURN_NULLS)) 
		{
			
			//on déclare un objet de type etudiant pour chaque ligne retourné par la requête
			$etudiant = new Etudiant($row);
		}
		//on retourne le tableau d'étudaint
		return $etudiant;
	}*/
	
}


?>