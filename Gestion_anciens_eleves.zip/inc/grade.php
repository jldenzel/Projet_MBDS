<?php
class Grade
{
	private $_grade;
	private $_numero_grade;
	
	
	public function __construct ($value = array())
	{
		if(!empty($value))
			$this->hydrate($value);
	}
	
	public function hydrate(array $data)
	{
		foreach($data as $key => $value)
		{
			$method = 'set'.ucfirst($key);
			if(method_exists($this, $method))
			{
				$this->$method($value);
			}
		}
	}
	
	public function numero_grade(){return $this->_numero_grade;}
	public function grade(){return $this->_grade;}
	
	
	public function setNumero_grade($numero_grade)
	{
		$this->_numero_grade=$numero_grade;
	}
	public function setGrade($grade)
	{
		$this->_grade=$grade;
	}
	
	
}

?>