<?php
class Association 
{
	private $_activite_association;
	private $_nom_association;
	private $_numero_association;
	
	public function __construct ($value = array())
	{
		if(!empty($value))
			$this->hydrate($value);
	}
	
	public function hydrate(array $data)
	{
		foreach($data as $key => $value)
		{
			$method = 'set'.ucfirst($key);
			if(method_exists($this, $method))
			{
				$this->$method($value);
			}
		}
	}
	
	public function activite_association(){return $this->_activite_association;}
	public function nom_association(){return $this->_nom_association;}
	public function numero_association(){return $this->_numero_association;}
	
	public function setActivite_association($activite_association)
	{
		$this->_activite_association=$activite_association;
	}
	public function setNom_association($nom_association)
	{
		$this->_nom_association=$nom_association;
	}
	public function setNumero_association($numero_association)
	{
		$this->_numero_association=$numero_association;
	}
	
}


?>