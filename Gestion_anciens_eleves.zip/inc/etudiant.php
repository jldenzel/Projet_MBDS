<?php
/*
**Classe etudiant représentant la table étudiant de la bdd
**
*/
class Etudiant 
{
	private $_prenom;
	private $_nationalite;
	private $_promotion;
	private $_mention;
	private $_nom_etudiant;
	private $_numero_etudiant;
	private $_Numero_entreprise;


	
	
	public function __construct ($value = array())
	{
		if(!empty($value))
			$this->hydrate($value);
	}
	
	public function hydrate(array $data)
	{
		foreach($data as $key => $value)
		{
			$method = 'set'.ucfirst($key);
			if(method_exists($this, $method))
			{
				$this->$method($value);
			}
		}
	}
	
	public function prenom(){return $this->_prenom;}
	public function nationalite(){return $this->_nationalite;}
	public function promotion(){return $this->_promotion;}
	public function mention(){return $this->_mention;}
	public function nom_etudiant(){return $this->_nom_etudiant;}
	public function numero_etudiant(){return $this->_numero_etudiant;}
	public function numero_entreprise(){return $this->_Numero_entreprise;}


	
	
	public function setPrenom($prenom)
	{
		$this->_prenom=$prenom;
	}
	public function setNationalite($nationalite)
	{
		$this->_nationalite=$nationalite;
	}
	public function setPromotion($promotion)
	{
		$this->_promotion=$promotion;
	}
	public function setMention($mention)
	{
		$this->_mention=$mention;
	}
	public function setNom_etudiant($nom_etudiant)
	{
		$this->_nom_etudiant=$nom_etudiant;
	}
	public function setNumero_etudiant($numero_etudiant)
	{
		$this->_numero_etudiant=$numero_etudiant;
	}
	public function setNumero_entreprise($numero_entreprise)
	{
		$this->_Numero_entreprise=$numero_entreprise;
	}

}



?>